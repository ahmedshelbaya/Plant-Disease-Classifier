# PLANT-DISEASE & Soil-CLASSIFIER-WEB-APP-TENSORFLOWJS

Tools and Technologies used 😇:-

1. Tensorflow (for training the model in Kaggle)
2. Tensorflow.js (Embedding the model for client-side/browser inference)
3. Javascript
4. Python
5. HTML and CSS

Made with Love by
